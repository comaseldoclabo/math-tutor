from datetime import timedelta

from fastapi import APIRouter, Depends, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import RedirectResponse
from sqlalchemy import delete, func, select
from sqlalchemy.orm import Session

from ..config import settings
from ..db import get_db
from ..models import (LEAD_STATUSES, Attempt, Chapter, ChatMessage, Classroom, ClassroomStudent, Chunk, Country,
                      Document, Exercise, Lead, Level, ParentChild, User, Workspace, now)
from ..security import can_view_student, require_role, require_user
from ..services import mathengine, notifier, rag
from ..services import progress as prog
from ..templating import flash, render

router = APIRouter()
staff = require_role("tutor", "admin")


def _workspace(db: Session, user: User) -> Workspace:
    ws = db.get(Workspace, user.workspace_id) if user.workspace_id else None
    if not ws:
        raise HTTPException(400, "Aucun espace de travail associé à ce compte.")
    return ws


def _students(db: Session, user: User) -> list[User]:
    return list(db.scalars(select(User).where(User.workspace_id == user.workspace_id, User.role == "student",
                                              User.is_active.is_(True)).order_by(User.name)))


def _summary(db: Session, s: User) -> dict:
    progress = prog.student_progress(db, s)
    return {"student": s, "overall": prog.overall(progress), "last": prog.last_activity(db, s.id),
            "activity": prog.daily_activity(db, s.id), "level": db.get(Level, s.level_id) if s.level_id else None}


# ---------------------------------------------------------------- tableau de bord
@router.get("/tutor")
def dashboard(request: Request, db: Session = Depends(get_db), user: User = Depends(staff)):
    ws = _workspace(db, user)
    rows = [_summary(db, s) for s in _students(db, user)]
    week_ago = now() - timedelta(days=7)
    attention = [r for r in rows if r["overall"]["struggling"] or not r["last"] or r["last"] < week_ago]
    active = sum(1 for r in rows if r["last"] and r["last"] >= week_ago)
    accs = [r["overall"]["accuracy"] for r in rows if r["overall"]["accuracy"]]
    feed = db.execute(
        select(Attempt, Exercise, User).join(Exercise, Attempt.exercise_id == Exercise.id)
        .join(User, Attempt.student_id == User.id)
        .where(User.workspace_id == ws.id).order_by(Attempt.id.desc()).limit(15)).all()
    return render(request, "tutor_home.html", user, ws=ws, rows=rows, attention=attention, active=active,
                  avg=(sum(accs) / len(accs)) if accs else 0.0, feed=feed)


@router.get("/tutor/students")
def students(request: Request, db: Session = Depends(get_db), user: User = Depends(staff)):
    ws = _workspace(db, user)
    rows = [_summary(db, s) for s in _students(db, user)]
    return render(request, "tutor_students.html", user, ws=ws, rows=rows)


# ---------------------------------------------------------------- fiche élève (tuteur, parent, élève)
@router.get("/students/{student_id}")
def student_detail(student_id: int, request: Request, ch: int | None = None, db: Session = Depends(get_db),
                   user: User = Depends(require_user)):
    s = db.get(User, student_id)
    if not s or not can_view_student(db, user, s):
        raise HTTPException(404, "Élève introuvable")
    progress = prog.student_progress(db, s)
    attempts = db.execute(select(Attempt, Exercise).join(Exercise, Attempt.exercise_id == Exercise.id)
                          .where(Attempt.student_id == s.id).order_by(Attempt.id.desc()).limit(15)).all()
    questions = db.scalars(select(ChatMessage).where(ChatMessage.user_id == s.id, ChatMessage.role == "user")
                           .order_by(ChatMessage.id.desc()).limit(8)).all()
    extra = {}
    if user.is_staff:
        extra["rooms"] = db.scalars(select(Classroom).where(Classroom.workspace_id == user.workspace_id)).all()
        extra["member_of"] = set(db.scalars(select(ClassroomStudent.classroom_id).where(
            ClassroomStudent.student_id == s.id)))
        extra["parents"] = db.scalars(select(User).join(ParentChild, ParentChild.parent_id == User.id)
                                      .where(ParentChild.child_id == s.id)).all()
    return render(request, "student_detail.html", user, s=s, progress=progress, overall=prog.overall(progress),
                  activity=prog.daily_activity(db, s.id), attempts=attempts, questions=questions,
                  level=db.get(Level, s.level_id) if s.level_id else None, highlight=ch, **extra)


@router.post("/students/{student_id}/note")
def send_note(student_id: int, request: Request, message: str = Form(...), db: Session = Depends(get_db),
              user: User = Depends(staff)):
    s = db.get(User, student_id)
    if not s or not can_view_student(db, user, s):
        raise HTTPException(404, "Élève introuvable")
    _, parents = notifier.recipients_for_student(db, s)
    notifier.notify(db, parents + [s.id], "message", f"Message de {user.name}", message.strip()[:1000],
                    f"/students/{s.id}")
    flash(request, "Message envoyé à l'élève et à ses parents.")
    return RedirectResponse(f"/students/{s.id}", status_code=303)


@router.post("/students/{student_id}/classroom")
def set_classroom(student_id: int, request: Request, classroom_id: int = Form(...), action: str = Form("add"),
                  db: Session = Depends(get_db), user: User = Depends(staff)):
    s = db.get(User, student_id)
    room = db.get(Classroom, classroom_id)
    if not s or not room or room.workspace_id != user.workspace_id or not can_view_student(db, user, s):
        raise HTTPException(404, "Introuvable")
    link = db.get(ClassroomStudent, (room.id, s.id))
    if action == "add" and not link:
        db.add(ClassroomStudent(classroom_id=room.id, student_id=s.id))
    elif action == "remove" and link:
        db.delete(link)
    db.commit()
    return RedirectResponse(f"/students/{s.id}", status_code=303)


# ---------------------------------------------------------------- classes
@router.get("/tutor/classes")
def classes(request: Request, db: Session = Depends(get_db), user: User = Depends(staff)):
    rooms = db.scalars(select(Classroom).where(Classroom.workspace_id == user.workspace_id)).all()
    members = {r.id: db.scalars(select(User).join(ClassroomStudent, ClassroomStudent.student_id == User.id)
                                .where(ClassroomStudent.classroom_id == r.id)).all() for r in rooms}
    levels = db.scalars(select(Level).order_by(Level.country_code, Level.position)).all()
    return render(request, "tutor_classes.html", user, rooms=rooms, members=members, levels=levels)


@router.post("/tutor/classes")
def create_class(request: Request, name: str = Form(...), level_id: str = Form(""), db: Session = Depends(get_db),
                 user: User = Depends(staff)):
    _workspace(db, user)
    db.add(Classroom(workspace_id=user.workspace_id, name=name.strip()[:120],
                     level_id=int(level_id) if level_id.isdigit() else None))
    db.commit()
    flash(request, "Classe créée.")
    return RedirectResponse("/tutor/classes", status_code=303)


# ---------------------------------------------------------------- documents (RAG)
@router.get("/tutor/docs")
def docs(request: Request, db: Session = Depends(get_db), user: User = Depends(staff)):
    ws = _workspace(db, user)
    items = db.scalars(select(Document).where(Document.workspace_id == ws.id).order_by(Document.id.desc())).all()
    counts = dict(db.execute(select(Chunk.document_id, func.count(Chunk.id)).group_by(Chunk.document_id)).all())
    countries = db.scalars(select(Country).order_by(Country.name)).all()
    levels = db.scalars(select(Level).order_by(Level.country_code, Level.position)).all()
    return render(request, "tutor_docs.html", user, ws=ws, items=items, counts=counts, countries=countries, levels=levels)


@router.post("/tutor/docs")
def upload_doc(request: Request, title: str = Form(...), country_code: str = Form(""), level_id: str = Form(""),
               file: UploadFile = File(...), db: Session = Depends(get_db), user: User = Depends(staff)):
    ws = _workspace(db, user)
    data = file.file.read(settings.UPLOAD_MAX_BYTES + 1)
    if len(data) > settings.UPLOAD_MAX_BYTES:
        flash(request, "Fichier trop volumineux.", "err")
        return RedirectResponse("/tutor/docs", status_code=303)
    try:
        text = rag.extract_text(file.filename or "", data)
    except Exception as exc:  # noqa: BLE001
        flash(request, f"Import impossible : {exc}", "err")
        return RedirectResponse("/tutor/docs", status_code=303)
    doc = Document(title=title.strip()[:200], source=(file.filename or "")[:200], workspace_id=ws.id,
                   country_code=country_code or None, level_id=int(level_id) if level_id.isdigit() else None,
                   uploaded_by=user.id, text=text)
    db.add(doc)
    db.flush()
    n = rag.index_document(db, doc)
    flash(request, f"Cours importé et indexé ({n} passages).")
    return RedirectResponse("/tutor/docs", status_code=303)


@router.post("/tutor/docs/{doc_id}/delete")
def delete_doc(doc_id: int, db: Session = Depends(get_db), user: User = Depends(staff)):
    doc = db.get(Document, doc_id)
    if doc and doc.workspace_id == user.workspace_id:
        db.execute(delete(Chunk).where(Chunk.document_id == doc.id))
        db.delete(doc)
        db.commit()
    return RedirectResponse("/tutor/docs", status_code=303)


# ---------------------------------------------------------------- exercices de l'espace
@router.get("/tutor/exercises")
def exercises(request: Request, db: Session = Depends(get_db), user: User = Depends(staff)):
    ws = _workspace(db, user)
    items = db.execute(select(Exercise, Chapter).join(Chapter, Exercise.chapter_id == Chapter.id)
                       .where(Exercise.workspace_id == ws.id).order_by(Exercise.id.desc())).all()
    chapters = db.execute(select(Chapter, Level).join(Level, Chapter.level_id == Level.id)
                          .order_by(Level.country_code, Level.position, Chapter.position)).all()
    return render(request, "tutor_exercises.html", user, ws=ws, items=items, chapters=chapters)


@router.post("/tutor/exercises")
def create_exercise(request: Request, chapter_id: int = Form(...), statement: str = Form(...),
                    answer: str = Form(...), hint: str = Form(""), difficulty: int = Form(1),
                    db: Session = Depends(get_db), user: User = Depends(staff)):
    ws = _workspace(db, user)
    if not db.get(Chapter, chapter_id):
        raise HTTPException(404, "Chapitre introuvable")
    try:
        mathengine.validate_expected(answer)
    except mathengine.MathError as exc:
        flash(request, f"Réponse attendue illisible par le moteur de calcul ({exc}). Exemples : x=4 ; 3/4 ; x^2+2x+1 ; x=2 ou x=-2.", "err")
        return RedirectResponse("/tutor/exercises", status_code=303)
    db.add(Exercise(chapter_id=chapter_id, workspace_id=ws.id, statement=statement.strip(), answer=answer.strip()[:200],
                    hint=hint.strip(), difficulty=max(1, min(3, difficulty))))
    db.commit()
    flash(request, "Exercice ajouté.")
    return RedirectResponse("/tutor/exercises", status_code=303)


@router.post("/tutor/exercises/{ex_id}/delete")
def delete_exercise(ex_id: int, db: Session = Depends(get_db), user: User = Depends(staff)):
    ex = db.get(Exercise, ex_id)
    if ex and ex.workspace_id == user.workspace_id:
        db.execute(delete(Attempt).where(Attempt.exercise_id == ex.id))
        db.delete(ex)
        db.commit()
    return RedirectResponse("/tutor/exercises", status_code=303)


# ---------------------------------------------------------------- CRM (prospects)
@router.get("/tutor/crm")
def crm(request: Request, db: Session = Depends(get_db), user: User = Depends(staff)):
    ws = _workspace(db, user)
    leads = db.scalars(select(Lead).where(Lead.workspace_id == ws.id).order_by(Lead.updated_at.desc())).all()
    columns = {s: [l for l in leads if l.status == s] for s in LEAD_STATUSES}
    return render(request, "crm.html", user, ws=ws, columns=columns, statuses=LEAD_STATUSES)


@router.post("/tutor/crm")
def crm_add(request: Request, name: str = Form(...), contact: str = Form(""), child_level: str = Form(""),
            source: str = Form(""), notes: str = Form(""), db: Session = Depends(get_db), user: User = Depends(staff)):
    ws = _workspace(db, user)
    db.add(Lead(workspace_id=ws.id, name=name.strip()[:120], contact=contact.strip()[:120],
                child_level=child_level.strip()[:60], source=source.strip()[:60], notes=notes.strip()))
    db.commit()
    return RedirectResponse("/tutor/crm", status_code=303)


@router.post("/tutor/crm/{lead_id}")
def crm_update(lead_id: int, status: str = Form(...), notes: str = Form(None), db: Session = Depends(get_db),
               user: User = Depends(staff)):
    lead = db.get(Lead, lead_id)
    if not lead or lead.workspace_id != user.workspace_id:
        raise HTTPException(404, "Introuvable")
    if status in LEAD_STATUSES:
        lead.status = status
    if notes is not None:
        lead.notes = notes.strip()
    lead.updated_at = now()
    db.commit()
    return RedirectResponse("/tutor/crm", status_code=303)


@router.post("/tutor/crm/{lead_id}/delete")
def crm_delete(lead_id: int, db: Session = Depends(get_db), user: User = Depends(staff)):
    lead = db.get(Lead, lead_id)
    if lead and lead.workspace_id == user.workspace_id:
        db.delete(lead)
        db.commit()
    return RedirectResponse("/tutor/crm", status_code=303)
